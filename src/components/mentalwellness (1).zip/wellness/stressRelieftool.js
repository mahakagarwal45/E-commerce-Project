const StressReliefTool= () => {
    const StressReliefTool = [
        { id: 1, name: '5 pc Fidget Toy', description: '5 PC Fidget Toy Stress Reliever', imageUrl: './5 PC Fidget Toy Stress Reliever.jpg' },
        { id: 2, name: 'Corona Virus Squeeze', description: 'Buy Dhjrefhhd 1Pcs Covid_19 Coronavirus Squeeze Stress Ball Stress Relief Tools', imageUrl: './Buy Dhjrefhhd 1Pcs Covid_19 Coronavirus Squeeze Stress Ball Stress Relief Tools.jpg' },
        { id: 3, name: 'Kemendra pop', description: 'Stress Relief Tool', imageUrl: './stressRelieftool.js' },
        { id: 4, name: 'Wooden handheld Massager', description: 'Wooden Handheld Foot Roller Acupressure Massager', imageUrl: './Wooden Handheld Foot Roller Acupressure Massager.jpg' },
        { id: 5, name: 'Tangles Fidget Toys', description: 'Ycvsad tangles Fidget Toys for Kids and Adults', imageUrl: './Ycvsad tangles Fidget Toys for Kids and Adult.jpg' }
    ];
    const backgroundStyle = {
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        padding: '20px'
    };

    return (
        <div className="StressReliefTool" style={backgroundStyle}>
            <h2>Mental Wellness Books</h2>
            <ul>
                {devices.map(StressReliefTool => (
                    <li key={StressReliefTools.id} className="StressReliefTool-item">
                        <img src={process.env.PUBLIC_URL + '/' +StressReliefTool.imageUrl} alt={StressReliefTool.name} className="StressReliefTool-image" />
                        <div className="StressReliefTool-info">
                            <h3>{StressReliefTool.name}</h3>
                            <p>{StressReliefTool.description}</p>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default StressReliefTool;