import React from 'react';
import './Navbar.css';

const Navbar = () => {
  return (
    <div className="navbar">
<input type="text" placeholder="Mental Wellness" />
<select>
  <option value="Books"><a href="">Books</a></option>
  <option value="Stress Relief tool"><a href="">Stress Relief tool</a></option>
  <option value="Meditation Aids"><a href="">Meditation Aids</a></option>
</select>
        <div className="navbar-right">
      <h2>Search</h2>
      <input type="text" placeholder="Search..." />


        <div className="navbar-buttons">
          <a href="#home" className="active">Home</a>
          <a href="#login">Login</a>
          <a href="#logout">Logout</a>
        </div>
      </div>
    </div>
  );
};

export default Navbar;