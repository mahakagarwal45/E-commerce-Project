const MentalWellness = () => {
    <select>
  <option value="Meditation Aids"><a href="./books.js">Meditation Aids</a></option>
  <option value="Mental Wellness Books"><a href="meditationaids.js">Mental Wellness Books</a></option>
  <option value="Stress Relief tool"><a href="stressRelieftool">Stress Relief tool</a></option>

</select>
    
    const backgroundStyle = {
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        padding: '20px'
    };

};

export default HealthDevices;
