const books = () => {
    const books = [
        { id: 1, name: 'the comfort book', description: 'mental wellness book', imageUrl: './thecomfortbook.jpeg' },
        { id: 2, name: 'Detox your Thoughts', description: 'mental wellness book', imageUrl: './detoxyourthoughts.jpeg' },
        { id: 3, name: 'MentalHeath and wellbeing in the workplace', description: 'mental wellness book', imageUrl: './MentalHeath and wellbeing in the workplace.jpeg' },
        { id: 4, name: 'mental welnnes blueprint', description: 'mental wellness book', imageUrl: './mentalwelnnesblueprint.jpeg' },
        { id: 5, name: 'the 7 habits of highly effective people', description: 'mental wellness book', imageUrl: './the7habitsofhighlyeffectivepeople.webp' },
        { id: 6, name: 'The highly sensitive person', description: 'mental wellness book', imageUrl: './thehighlysenstiveperson.webp' }
    ];
    const backgroundStyle = {
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        padding: '20px'
    };

    return (
        <div className="books" style={backgroundStyle}>
            <h2>Mental Wellness Books</h2>
            <ul>
                {devices.map(books => (
                    <li key={books.id} className="book-item">
                        <img src={process.env.PUBLIC_URL + '/' + books.imageUrl} alt={books.name} className="book-image" />
                        <div className="book-info">
                            <h3>{books.name}</h3>
                            <p>{books.description}</p>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default meditation;
